<#
.SYNOPSIS
    Generates a directory tree and saves it to a text file - ASCII safe version.

.DESCRIPTION
    ASCII-only tree so it never breaks on encoding. Works in PowerShell 5.1 and 7+.

.PARAMETER RootPath
    Folder to start from. Defaults to current directory.

.PARAMETER OutputFile
    File to write the tree to.

.PARAMETER MaxDepth
    How deep to recurse. Default 10, 0 = unlimited.

.PARAMETER IncludeFiles
    Include files in addition to folders.

.PARAMETER IncludeHidden
    Include hidden/system items.

.PARAMETER Exclude
    Folder names to exclude

.EXAMPLE
    .\To-DirectoryTree.ps1 -RootPath C:\Projects -OutputFile C:\Temp\tree.txt -IncludeFiles
#>
[CmdletBinding()]
param(
    [Parameter(Position=0)]
    [string]$RootPath = ".",
    [Parameter(Position=1)]
    [string]$OutputFile = ".\directory-tree.txt",
    [int]$MaxDepth = 10,
    [switch]$IncludeFiles,
    [switch]$IncludeHidden,
    [string[]]$Exclude = @('node_modules', '__pycache__', '.venv', '.pytest_cache', '.git', '.vs', 'bin', 'obj')
)

# Resolve paths
$RootPath = (Resolve-Path -LiteralPath $RootPath -ErrorAction Stop).Path
$OutputFile = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputFile)

# Buffer for output
$script:TreeLines = [System.Collections.Generic.List[string]]::new()
$script:TreeLines.Add($RootPath)

function Get-DirChildren {
    param([string]$Path)
    $params = @{
        LiteralPath = $Path
        Force = $IncludeHidden.IsPresent
        ErrorAction = 'SilentlyContinue'
    }
    $items = Get-ChildItem @params | Where-Object {
        if ($_.PSIsContainer) {
            $_.Name -notin $Exclude
        } else {
            $IncludeFiles.IsPresent
        }
    } | Sort-Object { -not $_.PSIsContainer }, Name
    return $items
}

function Write-Tree {
    param(
        [string]$Path,
        [string]$Prefix = "",
        [int]$Depth = 1
    )

    if ($MaxDepth -gt 0 -and $Depth -gt $MaxDepth) { return }

    $children = Get-DirChildren -Path $Path
    for ($i = 0; $i -lt $children.Count; $i++) {
        $child = $children[$i]
        $isLast = ($i -eq $children.Count - 1)
        
        # ASCII-safe connectors - never breaks encoding
        $connector = if ($isLast) { "+-- " } else { "|-- " }
        $script:TreeLines.Add("$Prefix$connector$($child.Name)")

        if ($child.PSIsContainer) {
            $newPrefix = $Prefix + $(if ($isLast) { "    " } else { "|   " })
            Write-Tree -Path $child.FullName -Prefix $newPrefix -Depth ($Depth + 1)
        }
    }
}

Write-Host "Generating tree for: $RootPath" -ForegroundColor Cyan
Write-Tree -Path $RootPath

# Write to file - ASCII encoding is safest for old PowerShell
$script:TreeLines | Out-File -FilePath $OutputFile -Encoding utf8 -Force

Write-Host "Done! Tree saved to: $OutputFile" -ForegroundColor Green
Write-Host "Total lines: $($script:TreeLines.Count)"
